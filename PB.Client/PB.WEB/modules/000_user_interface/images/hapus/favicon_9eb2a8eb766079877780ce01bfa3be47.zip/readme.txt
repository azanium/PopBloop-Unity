

Thank you for using our Animated FavIcon Generator - www.animatedfavicon.com! 
Here are the contents of this compressed package.



>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

*****  For Man

How To Approach Any Woman, Anywhere And Know Exactly What To Say
To Get Her To Give You Her Number 
And Go On A Date With You - NOW



Click Here for reading ebook

http://alturl.com/jsuw


*****  For Women

How To Get Your Ex Boyfrend Back

Click Here for reading ebook

http://alturl.com/ifxp


>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>




favicon.ico  --  The favicon file (supports both 16*16 and 32*32 dimensions).



1.  You can add a favicon to your web page by uploading favicon.ico to Root of your 

    website and inserting the following HTML tag between the <head> ... </head>

    tags of your web page.



      <link rel="shortcut icon" href="favicon.ico">



2.  How to use the Animated FavIcon: if you would like to display the animated favicon, upload

    animated_favicon.gif also and insert the following HTML tags.



      <link rel="shortcut icon" href="favicon.ico" >

      <link rel="icon" href="animated_favicon.gif" type="image/gif" >

     You can see the examplate at http://www.airportdisk.com



3.  Other extra files in this package



    The following files are included for your convenience. These are optional files:



    - favicon.ico - favicon.

    - preview_16x16.png - 16*16 PNG image file of the favicon.

    - preview_32x32.png - 32*32 PNG image file of the favicon.

    - animated_favicon.gif - animated version of the favicon.

    - readme.txt - this quick reference.


4.  We also have favicon directory. You can upload you images (Not Favicon) to our directory.
    You can get one way link and traffic from us.


If you think www.animatedfavicon.com is usefully, please kindly tell your friend about my website.


Many Thanks

1. http://alturl.com/b3gv - Free Keyword Tools
2. http://alturl.com/so9t - How to Build Traffic
3. http://alturl.com/yui9 -  Choosing the Best Keywords for AdSense

